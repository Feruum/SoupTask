import { expect, test } from '@playwright/test'

for (const [route, mark] of [
  ['/runs/kazakh-sft-005', 'soup:run-page-commit'],
  ['/compare?runs=kazakh-sft-005,kazakh-sft-001,kazakh-sft-002,kazakh-sft-006', 'soup:compare-page-commit']
] as const) {
  test(`hover updates source readouts without recommitting the surrounding page: ${mark}`, async ({ page }) => {
    await page.goto(route)
    await expect(page.locator('.plot-host').first()).toHaveAttribute('data-view-ready', 'true', { timeout: 60_000 })
    await page.evaluate(() => document.fonts.ready)
    const surface = page.locator('.u-over').first()
    await surface.scrollIntoViewIfNeeded()
    await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))))
    const box = await surface.boundingBox()
    if (!box) throw Error('Missing actual chart input surface')
    const before = await page.evaluate(name => performance.getEntriesByName(name).length, mark)
    for (const fraction of [.3, .4, .5]) {
      const sequence = await page.evaluate(() => (window as Window & { __soupEvidence?: { acceptedHoverSeq: number } }).__soupEvidence?.acceptedHoverSeq ?? 0)
      await page.mouse.move(box.x + box.width * fraction, box.y + box.height * .5)
      await expect.poll(() => page.evaluate(() => (performance.getEntriesByName('soup:hover-frame').at(-1) as PerformanceMark | undefined)?.detail?.hoverSeq ?? 0)).toBeGreaterThan(sequence)
      await expect(page.locator('.chart-hover-value').first()).toContainText('kazakh-sft-005')
    }
    expect(await page.evaluate(name => performance.getEntriesByName(name).length, mark)).toBe(before)
  })
}
