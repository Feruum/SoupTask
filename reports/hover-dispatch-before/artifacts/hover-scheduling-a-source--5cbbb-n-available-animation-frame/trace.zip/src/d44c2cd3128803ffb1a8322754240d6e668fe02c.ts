import { expect, test } from '@playwright/test'

test('a source hover request is dispatched without waiting for an available animation frame', async ({ page }) => {
  await page.addInitScript(() => {
    const tracked = window as Window & { __hoverPosts: number }
    tracked.__hoverPosts = 0
    const original = Worker.prototype.postMessage
    Worker.prototype.postMessage = function (message: unknown, options?: Transferable[] | StructuredSerializeOptions) {
      if (message && typeof message === 'object' && 'kind' in message && message.kind === 'hover') tracked.__hoverPosts++
      return Reflect.apply(original, this, [message, options])
    }
  })
  await page.goto('/runs/kazakh-sft-005')
  await expect(page.locator('.plot-host').first()).toHaveAttribute('data-view-ready', 'true', { timeout: 60_000 })
  await page.evaluate(() => document.fonts.ready)
  const surface = page.locator('.u-over').first()
  await surface.scrollIntoViewIfNeeded()
  await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))))
  const box = await surface.boundingBox()
  if (!box) throw Error('Missing actual chart input surface')
  const before = await page.evaluate(() => {
    const tracked = window as Window & { __hoverPosts: number; __releaseFrames?: () => void }
    const request = requestAnimationFrame, cancel = cancelAnimationFrame
    const frames = new Map<number, FrameRequestCallback>()
    let id = 1_000_000
    window.requestAnimationFrame = callback => { frames.set(++id, callback); return id }
    window.cancelAnimationFrame = handle => { if (!frames.delete(handle)) cancel(handle) }
    tracked.__releaseFrames = () => {
      window.requestAnimationFrame = request; window.cancelAnimationFrame = cancel
      for (const callback of frames.values()) request(callback)
      frames.clear()
    }
    return tracked.__hoverPosts
  })
  try {
    await page.mouse.move(box.x + box.width * .5, box.y + box.height * .5)
    await expect.poll(() => page.evaluate(() => (window as Window & { __hoverPosts: number }).__hoverPosts)).toBeGreaterThan(before)
  } finally { await page.evaluate(() => (window as Window & { __releaseFrames?: () => void }).__releaseFrames?.()) }
})

for (const [route, mark] of [
  ['/runs/kazakh-sft-005', 'soup:run-page-commit'],
  ['/compare?runs=kazakh-sft-005,kazakh-sft-001,kazakh-sft-002,kazakh-sft-006', 'soup:compare-page-commit']
] as const) {
  test(`hover updates source readouts without recommitting the surrounding page: ${mark}`, async ({ page }) => {
    await page.goto(route)
    await expect(page.locator('.plot-host').first()).toHaveAttribute('data-view-ready', 'true', { timeout: 60_000 })
    await page.evaluate(() => document.fonts.ready)
    const surface = page.locator('.u-over').first()
    await surface.scrollIntoViewIfNeeded()
    await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))))
    const box = await surface.boundingBox()
    if (!box) throw Error('Missing actual chart input surface')
    const before = await page.evaluate(name => performance.getEntriesByName(name).length, mark)
    for (const fraction of [.3, .4, .5]) {
      const sequence = await page.evaluate(() => (window as Window & { __soupEvidence?: { acceptedHoverSeq: number } }).__soupEvidence?.acceptedHoverSeq ?? 0)
      await page.mouse.move(box.x + box.width * fraction, box.y + box.height * .5)
      await expect.poll(() => page.evaluate(() => (performance.getEntriesByName('soup:hover-frame').at(-1) as PerformanceMark | undefined)?.detail?.hoverSeq ?? 0)).toBeGreaterThan(sequence)
      await expect(page.locator('.chart-hover-value').first()).toContainText('kazakh-sft-005')
    }
    expect(await page.evaluate(name => performance.getEntriesByName(name).length, mark)).toBe(before)
  })
}
