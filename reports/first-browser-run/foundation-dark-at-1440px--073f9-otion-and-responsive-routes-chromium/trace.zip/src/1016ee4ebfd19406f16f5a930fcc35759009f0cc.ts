import AxeBuilder from '@axe-core/playwright'
import { expect, test } from '@playwright/test'

test('keyboard navigation opens a Worker-backed uPlot chart and handles an unknown run', async ({ page }) => {
  const pageErrors: string[] = []
  page.on('pageerror', error => pageErrors.push(error.message))
  await page.goto('/runs')
  await expect(page.getByRole('heading', { name: 'Training runs', exact: true })).toBeVisible()
  await page.getByRole('link', { name: 'Open kazakh-sft-003' }).focus()
  await page.keyboard.press('Enter')
  await expect(page).toHaveURL(/\/runs\/kazakh-sft-003$/)
  await expect(page.getByRole('heading', { name: 'kazakh-sft-003', exact: true })).toBeVisible()
  await expect(page.locator('[data-testid="loss-chart"] .uplot')).toHaveCount(1)
  await expect(page.getByTestId('peak-loss')).toHaveText('8.742')
  await page.getByLabel('Source step').fill('2560')
  await page.getByRole('button', { name: 'Inspect step', exact: true }).click()
  await expect(page.getByTestId('inspected-loss')).toHaveText('8.742')
  await page.getByRole('button', { name: 'Zoom in', exact: true }).focus()
  await page.keyboard.press('Enter')
  await expect(page.getByTestId('visible-range')).toContainText('1,277.5')
  await page.getByRole('button', { name: 'Reset view', exact: true }).click()
  await expect(page.getByTestId('visible-range')).toContainText('5,110')
  await page.goto('/runs/unknown')
  await expect(page.getByRole('heading', { name: 'Run not found' })).toBeVisible()
  expect(pageErrors).toEqual([])
})

for (const theme of ['dark', 'light'] as const) {
  for (const width of [320, 1440]) {
    test(`${theme} at ${width}px: axe, reduced motion and responsive routes`, async ({ page }, testInfo) => {
      await page.emulateMedia({ reducedMotion: 'reduce' })
      await page.setViewportSize({ width, height: 1000 })
      await page.goto('/runs')
      for (const route of ['/runs', '/runs/kazakh-sft-003', '/compare', '/data-quality']) {
        await page.goto(route)
        if (theme === 'light') await page.getByRole('button', { name: 'Switch to light theme' }).click()
        await expect(page.locator('html')).toHaveAttribute('data-theme', theme)
        if (route.includes('003')) await expect(page.locator('[data-testid="loss-chart"] .uplot')).toHaveCount(1)
        const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']).analyze()
        await testInfo.attach(`${theme}-${width}-${route.split('/').at(-1)}-axe`, { body: JSON.stringify(results, null, 2), contentType: 'application/json' })
        expect(results.violations).toEqual([])
        expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true)
        expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches)).toBe(true)
        await expect(page.getByRole('link', { name: 'Skip to content' })).toHaveAttribute('href', '#main-content')
        const moving = await page.evaluate(() => document.getAnimations().filter(animation => animation.playState === 'running' && animation.effect?.getTiming().iterations === Infinity).length)
        expect(moving).toBe(0)
        await page.screenshot({ path: testInfo.outputPath(`${theme}-${width}-${route.split('/').at(-1)}.png`), fullPage: true })
      }
    })
  }
}

test('search empty state and missing-value fixture remain explicit', async ({ page }) => {
  await page.goto('/runs')
  await page.getByRole('searchbox', { name: 'Search runs' }).fill('does-not-exist')
  await expect(page.getByRole('heading', { name: 'No matching runs' })).toBeVisible()
  await page.getByRole('button', { name: 'Clear filters', exact: true }).click()
  await expect(page.getByRole('link', { name: 'Open kazakh-sft-001' })).toBeVisible()
  await page.goto('/runs/kazakh-sft-001')
  await expect(page.locator('[data-testid="loss-chart"] .uplot')).toHaveCount(1)
  await page.getByLabel('Source step').fill('3200')
  await page.getByRole('button', { name: 'Inspect step', exact: true }).click()
  await expect(page.getByTestId('inspected-loss')).toHaveText('NaN')
  await expect(page.getByText('1 invalid loss observation. The chart leaves a gap.')).toBeVisible()
})

test('all generated navigation pages are connected and comparison uses real fixture data', async ({ page }) => {
  await page.goto('/runs')
  await page.getByRole('link', { name: 'Compare', exact: true }).click()
  await expect(page).toHaveURL(/\/compare$/)
  await expect(page.getByRole('heading', { name: 'Compare runs', exact: true })).toBeVisible()
  await expect(page.getByTestId('comparison-loss').locator('.uplot')).toHaveCount(1)
  await page.getByLabel('Compare kazakh-sft-003').uncheck()
  await expect(page.getByText('2 runs selected', { exact: true })).toBeVisible()
  await page.getByRole('link', { name: 'Data quality', exact: true }).click()
  await expect(page).toHaveURL(/\/data-quality$/)
  await expect(page.getByRole('heading', { name: 'Data quality', exact: true })).toBeVisible()
  await page.getByRole('link', { name: 'Inspect missing value' }).click()
  await expect(page).toHaveURL(/kazakh-sft-001\?step=3200$/)
  await expect(page.getByTestId('inspected-loss')).toHaveText('NaN')
})
